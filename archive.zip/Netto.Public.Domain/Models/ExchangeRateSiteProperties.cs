﻿namespace Netto.Public.Domain.Models
{
    public class ExchangeRateSiteProperties
    {
        public string URL { get; set; }
        public string DivExchangeRateClass { get; set; }
    }
}
