﻿namespace Netto.Public.Domain.Models
{
    public class BankRequirementModel
    {
        public string City { get; set; }
        public string Adress { get; set; }
    }
}
