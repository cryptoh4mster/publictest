﻿namespace Netto.Public.Domain.Exceptions.BusinessExceptions
{
    public class BusinessNettoException : NettoException
    {
        public BusinessNettoException(string message) : base(message)
        {
        }
    }
}
