﻿namespace Netto.Public.Domain.Exceptions
{
    public class NettoException : Exception
    {
        public NettoException(string message) : base(message)
        {
        }
    }
}
