﻿namespace Netto.Public.Domain.Exceptions.SystemExceptions
{
    public class SystemNettoException : NettoException
    {
        public SystemNettoException(string message) : base(message)
        {
        }
    }
}
