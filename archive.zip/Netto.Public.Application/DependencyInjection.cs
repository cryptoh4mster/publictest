﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Netto.Public.Application.Services;
using Netto.Public.Core.Interfaces;

namespace Netto.Public.Application
{
    public static class DependencyInjection
    {
        public static void AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IPublicService, PublicService>();
            services.AddScoped<ICurrencyService, CurrencyService>();
        }
    }
}
