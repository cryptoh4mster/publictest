﻿namespace Netto.Public.DataContext.Entities
{
    public class Extras
    {
        public Guid BankId { get; set; }
        public bool HasPandus { get; set; }
        public bool HasExoticExchange { get; set; }
        public bool HasConsultation { get; set; }
        public bool HasInsurance { get; set; }

        public Bank Bank { get; set; }
    }
}
