﻿using Netto.Public.API.ExceptionResolvers;
using Netto.Public.API.ExceptionResolvers.Base;

namespace Netto.Public.API
{
    public static class ExceptionFilterDI
    {
        public static void AddExceptionsFilter(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IExceptionResolver, GlobalExceptionResolver>();
        }
    }
}
