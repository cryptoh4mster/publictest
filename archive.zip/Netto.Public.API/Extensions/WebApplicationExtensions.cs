﻿namespace Netto.Public.API.Extensions
{
    public static class WebApplicationExtensions
    {
        public static void UseCustomCors(this WebApplication app)
        {
            app.UseCors(builder =>
                builder.AllowAnyOrigin()
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    );
        }

    }
}
