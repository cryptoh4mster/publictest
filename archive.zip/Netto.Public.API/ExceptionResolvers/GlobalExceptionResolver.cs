﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Netto.Public.API.ExceptionResolvers.Base;
using Netto.Public.API.Models.Responses;

namespace Netto.Public.API.ExceptionResolvers
{
    public class GlobalExceptionResolver : IExceptionResolver
    {
        private readonly ILogger _logger;
        public GlobalExceptionResolver(ILogger<GlobalExceptionResolver> logger)
        {
            _logger = logger;
        }
        public void OnException(ExceptionContext context)
        {
            var id = Guid.NewGuid();
            var errorResponse = new ErrorBodyResponse<string>
            {
                Code = 2001,
                ErrorMessage = "Internal server error"
            };

            _logger.LogCritical(context.Exception, $"ErrorId : {id}");
            context.HttpContext.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Result = new ObjectResult(errorResponse);
        }
    }
}
