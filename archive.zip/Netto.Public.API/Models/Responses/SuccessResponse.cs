﻿using Netto.Public.API.Models.Responses.Base;

namespace Netto.Public.API.Models.Responses
{
    public class SuccessResponse : Response
    {
        public SuccessResponse()
        {
            IsSuccess = true;
        }
    }
}
