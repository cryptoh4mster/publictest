﻿using Netto.Public.API.Models.Responses.Base;

namespace Netto.Public.API.Models.Responses
{
    public class SuccessBodyResponse<T> : Response
    {
        public SuccessBodyResponse(T body)
        {
            Body = body;
            IsSuccess = true;
        }

        public T Body { get; set; }
    }
}
