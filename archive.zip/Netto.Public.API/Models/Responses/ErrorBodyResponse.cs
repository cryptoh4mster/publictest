﻿using Netto.Public.API.Models.Responses.Base;

namespace Netto.Public.API.Models.Responses
{
    public class ErrorBodyResponse<T> : Response
    {
        public ErrorBodyResponse()
        {
            IsSuccess = false;
        }

        public string ErrorMessage { get; set; }
        public T Body { get; set; }
        public int Code { get; set; }
    }
}
