﻿using Netto.Public.API.Models.Responses.Base;

namespace Netto.Public.API.Models.Responses
{
    public class ErrorResponse : Response
    {
        public ErrorResponse()
        {
            IsSuccess = false;
        }

        public string ErrorMessage { get; set; }
        public int Code { get; set; }
    }
}
