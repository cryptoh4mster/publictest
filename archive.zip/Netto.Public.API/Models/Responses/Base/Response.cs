﻿namespace Netto.Public.API.Models.Responses.Base
{
    public class Response
    {
        public bool IsSuccess { get; protected set; }
    }
}
