﻿namespace Netto.Public.API.Models.Requests
{
    public class ContactsRequest
    {
        public string Country { get; set; }
    }
}
