using FluentValidation.AspNetCore;
using Microsoft.OpenApi.Models;
using Netto.Public.API;
using Netto.Public.API.ExceptionResolvers;
using Netto.Public.API.ExceptionResolvers.Base;
using Netto.Public.API.Filters;
using Netto.Public.Application;
using Netto.Public.DataContext;
using Netto.Public.Domain.Exceptions;
using Netto.Public.Domain.Models;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Netto.Public.API.Extensions;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddExceptionsFilter(builder.Configuration);
builder.Services.AddDataContext(builder.Configuration);

builder.Services.AddApplication(builder.Configuration);

builder.Services.AddScoped<IExceptionResolver<NoBranchesAndATMException>, NoBranchesAndATMExceptionResolver>();
builder.Services.AddScoped<IExceptionResolver<ContactsNotFoundException>, ContactsNotFoundExceptionResolver>();
builder.Services.AddScoped<IExceptionResolver<WrongCurrencyISOCodeException>, WrongCurrencyISOCodeExceptionResolver>();

builder.Host.ConfigureAppConfiguration((hostingContext, config) =>
{
    config.AddJsonFile("appsettings.Override.json",
                       optional: true,
                       reloadOnChange: true);
});

builder.Services.Configure<ExchangeRateSiteProperties>(builder.Configuration.GetSection("ExchangeRateSiteProperties"));

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
builder.Services.AddControllers()
                .AddMvcOptions(options =>
                {
                    options.Filters.Add<ValidatorActionFilter>();
                    options.Filters.Add<ExceptionFilter>();
                    options.Filters.Add<ResponseFilter>();
                })
                .ConfigureApiBehaviorOptions(options =>
                {
                    options.SuppressModelStateInvalidFilter = true;
                    options.InvalidModelStateResponseFactory = c =>
                    {
                        var errors = c.ModelState.Values.Where(v => v.Errors.Count > 0)
                            .SelectMany(v => v.Errors)
                            .Select(v => v.ErrorMessage);

                        string json = JsonSerializer.Serialize(errors);
                        throw new ValidationException(json);
                    };
                })
                .AddFluentValidation(fv =>
                {
                    fv.RegisterValidatorsFromAssemblyContaining<Program>();
                    fv.AutomaticValidationEnabled = true;
                    fv.ImplicitlyValidateChildProperties = true;
                    fv.DisableDataAnnotationsValidation = true;
                });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "netto_new_public", Version = "v1" });
});


var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger(c => { c.SerializeAsV2 = true; });
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "netto_new_public v1"));

}

app.UseHttpsRedirection();

app.UseCustomCors();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
